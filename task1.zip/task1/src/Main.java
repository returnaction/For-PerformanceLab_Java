import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        while (true) {
            int length = validInput(scanner, "Введите длинну массива: ");
            int interval = validInput(scanner, "Введите интервал: ");

            int[] arr = new int[length];
            for (int i = 0; i < length; i++) {
                arr[i] = i + 1;
            }

            System.out.print("Path: ");
            int current = 0;
            do {
                System.out.print(arr[current]);
                current += interval - 1;
                if (current >= length) {
                    current -= length;
                }
            } while (current != 0);

            System.out.println("\nНажми \"Enter\" для повтора");
            scanner.nextLine();
            scanner.nextLine();
        }

    }

    private static int validInput(Scanner scanner, String message) {
        int value;
        while (true) {
            System.out.println(message);
            if (!scanner.hasNextInt()) {
                System.out.println("Неправильный ввод, должно быть число\n");
                scanner.next();
                continue;
            }
            value = scanner.nextInt();
            break;
        }
        return value;
    }
}