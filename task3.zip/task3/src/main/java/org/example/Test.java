package org.example;

import java.util.List;

public class Test {
    private int id;
    private String title;
    private String value;
    private List<Test> values;

    // get set id
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    // get set title
    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    // get set value
    public String getValue(){
        return value;
    }

    public void setValue(String value){
        this.value = value;
    }

    // get set List values
    public List<Test> getValues(){
        return values;
    }

    public void setValues(List<Test> values){
        this.values = values;
    }
}
