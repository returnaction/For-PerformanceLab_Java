package org.example;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        String reportFilePath = "C:\\Users\\Oberg\\IdeaProjects\\task3\\report.json";
        String testFilePath = "C:\\Users\\Oberg\\IdeaProjects\\task3\\tests.json";
        String valuesFilePath = "C:\\Users\\Oberg\\IdeaProjects\\task3\\values.json";

        try{

            // для Json
            Gson gson = new Gson();

            // reading tests
            FileReader fileReaderTestsImport = new FileReader(testFilePath);
            Type testListType = new TypeToken<TestList>(){}.getType();
            TestList testList = gson.fromJson(fileReaderTestsImport, testListType);
            fileReaderTestsImport.close();

            // reading values
            FileReader fileReaderValuesImport = new FileReader(valuesFilePath);
            Type valueListType = new TypeToken<ValueList>(){}.getType();
            ValueList valueList = gson.fromJson(fileReaderValuesImport, valueListType);
            fileReaderValuesImport.close();

            // writing down the values
            Map<Integer, String> valueMap = new HashMap<>();

            List<Value> values = valueList.getValues();

            for(int i = 0; i < values.size(); i++){
                Value value = values.get(i);
                valueMap.put(value.getId(), value.getValue());
            }

            // filling up the values
            List<Test> tests = testList.getTestList();


            // create  additional function to fill up the tests



        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }


}

