package org.example;

import java.util.List;

public class TestList {
    private List<Test> tests;

    public List<Test> getTestList(){
        return tests;
    }

    public void setTestList(List<Test> tests){
        this.tests = tests;
    }
}
