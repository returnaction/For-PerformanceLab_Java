import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Написал полную ерунду, но работает =)
        // Единственное уже не тратил время на то как передвать файлы в качестве аргументов, потому что c IntellIJ не знаком. Писал всегда на Visual Studio
        //  и решил потратить болтше времени на изучение JAVA
        String circleFilePath = "C:\\Users\\Oberg\\IdeaProjects\\task2\\File1.txt";
        String dotsFilePath = "C:\\Users\\Oberg\\IdeaProjects\\task2\\File2.txt";

        try{
            // читаем круг и радиус
            BufferedReader circleBufferReader = new BufferedReader(new FileReader(circleFilePath));
            String line;
            ArrayList<String> dotsAndRadiusString = new ArrayList<>();
            while((line = circleBufferReader.readLine()) != null){
               String[] temps = line.split(" ");
                dotsAndRadiusString.addAll(Arrays.asList(temps));

            }
            double[] dotsAndradiysDouble = new double[3];
            int index = 0;
            for(String value : dotsAndRadiusString){
                if(!value.isEmpty()){
                    dotsAndradiysDouble[index++] = Double.parseDouble(value);
                }
            }
            // Наши точки Х и Y и радиус
            double circleDotX = dotsAndradiysDouble[0];
            double circleDotY = dotsAndradiysDouble[1];
            double radiusOfCircle = dotsAndradiysDouble[2];
            circleBufferReader.close();

            // читаем точки
            BufferedReader dotsBufferReader = new BufferedReader(new FileReader(dotsFilePath));
            ArrayList<double[]> dotsList = new ArrayList<>();
            while((line = dotsBufferReader.readLine()) != null){
                String[] temps = line.split(" ");
                double[] dot = new double[2];
                dot[0] = Double.parseDouble(temps[0]);
                dot[1] = Double.parseDouble(temps[1]);
                dotsList.add(dot);
            }
            circleBufferReader.close();


            //  Вовыдим результаты на сонсоль
            for(int i = 0; i < dotsList.size(); i++){

                double distance = Calculate(circleDotX, circleDotY, dotsList.get(i)[0], dotsList.get(i)[1] );
                PrintResult(radiusOfCircle, distance);
            }

        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }


    }

    static double Calculate(double circleDotX, double circleDotY, double dotX, double dotY){
        return Math.sqrt(Math.pow(dotX - circleDotX, 2) + Math.pow(dotY - circleDotY, 2));
    }

    static void PrintResult(double radius, double distance){
        if(distance < radius){
            System.out.println("Точка расположена внутри круга");
        }
        else if(distance > radius){
            System.out.println("Точка расположена за кругом");
        }
        else{
            System.out.println("Точка расположена на радиусе круга");
        }
    }


}